﻿namespace MaquinaExpEstado03
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.p1Fondo = new System.Windows.Forms.Panel();
            this.p2Fondo = new System.Windows.Forms.Panel();
            this.pb12 = new System.Windows.Forms.PictureBox();
            this.pb11 = new System.Windows.Forms.PictureBox();
            this.pb10 = new System.Windows.Forms.PictureBox();
            this.pb9 = new System.Windows.Forms.PictureBox();
            this.pb8 = new System.Windows.Forms.PictureBox();
            this.pb7 = new System.Windows.Forms.PictureBox();
            this.pb6 = new System.Windows.Forms.PictureBox();
            this.pb5 = new System.Windows.Forms.PictureBox();
            this.pb16 = new System.Windows.Forms.PictureBox();
            this.pb15 = new System.Windows.Forms.PictureBox();
            this.pb14 = new System.Windows.Forms.PictureBox();
            this.pb13 = new System.Windows.Forms.PictureBox();
            this.pb4 = new System.Windows.Forms.PictureBox();
            this.pb3 = new System.Windows.Forms.PictureBox();
            this.pb2 = new System.Windows.Forms.PictureBox();
            this.pb1 = new System.Windows.Forms.PictureBox();
            this.p3Dispensador = new System.Windows.Forms.Panel();
            this.p4Dispensador2 = new System.Windows.Forms.Panel();
            this.p5Etiquetas4 = new System.Windows.Forms.Panel();
            this.lblSP16 = new System.Windows.Forms.Label();
            this.lblSP15 = new System.Windows.Forms.Label();
            this.lblSP14 = new System.Windows.Forms.Label();
            this.lblSP13 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.p4Etiquetas3 = new System.Windows.Forms.Panel();
            this.lblSP12 = new System.Windows.Forms.Label();
            this.lblSP11 = new System.Windows.Forms.Label();
            this.lblSP10 = new System.Windows.Forms.Label();
            this.lblSP9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.p3Etiquetas2 = new System.Windows.Forms.Panel();
            this.lblSP8 = new System.Windows.Forms.Label();
            this.lblSP7 = new System.Windows.Forms.Label();
            this.lblSP6 = new System.Windows.Forms.Label();
            this.lblSP5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.p2Etiquetas1 = new System.Windows.Forms.Panel();
            this.lblSP4 = new System.Windows.Forms.Label();
            this.lblSP3 = new System.Windows.Forms.Label();
            this.lblSP2 = new System.Windows.Forms.Label();
            this.lblSP1 = new System.Windows.Forms.Label();
            this.lblPrecio4 = new System.Windows.Forms.Label();
            this.lblPrecio3 = new System.Windows.Forms.Label();
            this.lblPrecio2 = new System.Windows.Forms.Label();
            this.lblPrecio1 = new System.Windows.Forms.Label();
            this.p1Teclado = new System.Windows.Forms.Panel();
            this.p2Teclado = new System.Windows.Forms.Panel();
            this.btCancelar = new System.Windows.Forms.Button();
            this.bt0 = new System.Windows.Forms.Button();
            this.btAceptar = new System.Windows.Forms.Button();
            this.bt9 = new System.Windows.Forms.Button();
            this.bt8 = new System.Windows.Forms.Button();
            this.bt7 = new System.Windows.Forms.Button();
            this.bt6 = new System.Windows.Forms.Button();
            this.bt5 = new System.Windows.Forms.Button();
            this.bt4 = new System.Windows.Forms.Button();
            this.bt3 = new System.Windows.Forms.Button();
            this.bt2 = new System.Windows.Forms.Button();
            this.bt1 = new System.Windows.Forms.Button();
            this.txtPantalla = new System.Windows.Forms.TextBox();
            this.p1Cambio = new System.Windows.Forms.Panel();
            this.p2Cambio = new System.Windows.Forms.Panel();
            this.lblPantalla = new System.Windows.Forms.Label();
            this.tmPrecio = new System.Windows.Forms.Timer(this.components);
            this.tmLimpiar = new System.Windows.Forms.Timer(this.components);
            this.lblCambio = new System.Windows.Forms.Label();
            this.tmDispensar = new System.Windows.Forms.Timer(this.components);
            this.pbBilletes = new System.Windows.Forms.PictureBox();
            this.pbMonedas = new System.Windows.Forms.PictureBox();
            this.p1Fondo.SuspendLayout();
            this.p2Fondo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).BeginInit();
            this.p3Dispensador.SuspendLayout();
            this.p5Etiquetas4.SuspendLayout();
            this.p4Etiquetas3.SuspendLayout();
            this.p3Etiquetas2.SuspendLayout();
            this.p2Etiquetas1.SuspendLayout();
            this.p1Teclado.SuspendLayout();
            this.p2Teclado.SuspendLayout();
            this.p1Cambio.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBilletes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMonedas)).BeginInit();
            this.SuspendLayout();
            // 
            // p1Fondo
            // 
            this.p1Fondo.BackColor = System.Drawing.Color.DarkGray;
            this.p1Fondo.Controls.Add(this.p2Fondo);
            this.p1Fondo.Location = new System.Drawing.Point(14, 10);
            this.p1Fondo.Name = "p1Fondo";
            this.p1Fondo.Size = new System.Drawing.Size(338, 670);
            this.p1Fondo.TabIndex = 7;
            // 
            // p2Fondo
            // 
            this.p2Fondo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.p2Fondo.Controls.Add(this.pb12);
            this.p2Fondo.Controls.Add(this.pb11);
            this.p2Fondo.Controls.Add(this.pb10);
            this.p2Fondo.Controls.Add(this.pb9);
            this.p2Fondo.Controls.Add(this.pb8);
            this.p2Fondo.Controls.Add(this.pb7);
            this.p2Fondo.Controls.Add(this.pb6);
            this.p2Fondo.Controls.Add(this.pb5);
            this.p2Fondo.Controls.Add(this.pb16);
            this.p2Fondo.Controls.Add(this.pb15);
            this.p2Fondo.Controls.Add(this.pb14);
            this.p2Fondo.Controls.Add(this.pb13);
            this.p2Fondo.Controls.Add(this.pb4);
            this.p2Fondo.Controls.Add(this.pb3);
            this.p2Fondo.Controls.Add(this.pb2);
            this.p2Fondo.Controls.Add(this.pb1);
            this.p2Fondo.Controls.Add(this.p3Dispensador);
            this.p2Fondo.Controls.Add(this.p5Etiquetas4);
            this.p2Fondo.Controls.Add(this.p4Etiquetas3);
            this.p2Fondo.Controls.Add(this.p3Etiquetas2);
            this.p2Fondo.Controls.Add(this.p2Etiquetas1);
            this.p2Fondo.Location = new System.Drawing.Point(6, 7);
            this.p2Fondo.Name = "p2Fondo";
            this.p2Fondo.Size = new System.Drawing.Size(326, 655);
            this.p2Fondo.TabIndex = 1;
            this.p2Fondo.Paint += new System.Windows.Forms.PaintEventHandler(this.p1Fondo_Paint);
            // 
            // pb12
            // 
            this.pb12.BackgroundImage = global::MaquinaExpEstado03.Properties.Resources.jugo_de_manzana;
            this.pb12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb12.Location = new System.Drawing.Point(250, 274);
            this.pb12.Name = "pb12";
            this.pb12.Size = new System.Drawing.Size(60, 80);
            this.pb12.TabIndex = 20;
            this.pb12.TabStop = false;
            // 
            // pb11
            // 
            this.pb11.BackgroundImage = global::MaquinaExpEstado03.Properties.Resources.jugo3;
            this.pb11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb11.Location = new System.Drawing.Point(172, 274);
            this.pb11.Name = "pb11";
            this.pb11.Size = new System.Drawing.Size(60, 80);
            this.pb11.TabIndex = 19;
            this.pb11.TabStop = false;
            // 
            // pb10
            // 
            this.pb10.BackgroundImage = global::MaquinaExpEstado03.Properties.Resources.jugo2;
            this.pb10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb10.Location = new System.Drawing.Point(91, 274);
            this.pb10.Name = "pb10";
            this.pb10.Size = new System.Drawing.Size(60, 80);
            this.pb10.TabIndex = 18;
            this.pb10.TabStop = false;
            // 
            // pb9
            // 
            this.pb9.BackgroundImage = global::MaquinaExpEstado03.Properties.Resources.jugo1;
            this.pb9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb9.Location = new System.Drawing.Point(22, 274);
            this.pb9.Name = "pb9";
            this.pb9.Size = new System.Drawing.Size(60, 80);
            this.pb9.TabIndex = 17;
            this.pb9.TabStop = false;
            // 
            // pb8
            // 
            this.pb8.BackgroundImage = global::MaquinaExpEstado03.Properties.Resources.galleta4;
            this.pb8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb8.Location = new System.Drawing.Point(238, 144);
            this.pb8.Name = "pb8";
            this.pb8.Size = new System.Drawing.Size(70, 80);
            this.pb8.TabIndex = 16;
            this.pb8.TabStop = false;
            // 
            // pb7
            // 
            this.pb7.BackgroundImage = global::MaquinaExpEstado03.Properties.Resources.galleta3;
            this.pb7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb7.Location = new System.Drawing.Point(161, 144);
            this.pb7.Name = "pb7";
            this.pb7.Size = new System.Drawing.Size(70, 80);
            this.pb7.TabIndex = 15;
            this.pb7.TabStop = false;
            // 
            // pb6
            // 
            this.pb6.BackgroundImage = global::MaquinaExpEstado03.Properties.Resources.galleta2;
            this.pb6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb6.Location = new System.Drawing.Point(94, 144);
            this.pb6.Name = "pb6";
            this.pb6.Size = new System.Drawing.Size(60, 80);
            this.pb6.TabIndex = 14;
            this.pb6.TabStop = false;
            // 
            // pb5
            // 
            this.pb5.BackgroundImage = global::MaquinaExpEstado03.Properties.Resources.galleta1;
            this.pb5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb5.Location = new System.Drawing.Point(18, 144);
            this.pb5.Name = "pb5";
            this.pb5.Size = new System.Drawing.Size(60, 80);
            this.pb5.TabIndex = 13;
            this.pb5.TabStop = false;
            // 
            // pb16
            // 
            this.pb16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb16.BackgroundImage")));
            this.pb16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb16.Location = new System.Drawing.Point(241, 404);
            this.pb16.Name = "pb16";
            this.pb16.Size = new System.Drawing.Size(70, 80);
            this.pb16.TabIndex = 12;
            this.pb16.TabStop = false;
            // 
            // pb15
            // 
            this.pb15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb15.BackgroundImage")));
            this.pb15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb15.Location = new System.Drawing.Point(169, 404);
            this.pb15.Name = "pb15";
            this.pb15.Size = new System.Drawing.Size(60, 80);
            this.pb15.TabIndex = 11;
            this.pb15.TabStop = false;
            // 
            // pb14
            // 
            this.pb14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb14.BackgroundImage")));
            this.pb14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb14.Location = new System.Drawing.Point(93, 404);
            this.pb14.Name = "pb14";
            this.pb14.Size = new System.Drawing.Size(60, 80);
            this.pb14.TabIndex = 10;
            this.pb14.TabStop = false;
            // 
            // pb13
            // 
            this.pb13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb13.BackgroundImage")));
            this.pb13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb13.Location = new System.Drawing.Point(18, 404);
            this.pb13.Name = "pb13";
            this.pb13.Size = new System.Drawing.Size(60, 80);
            this.pb13.TabIndex = 9;
            this.pb13.TabStop = false;
            // 
            // pb4
            // 
            this.pb4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb4.BackgroundImage")));
            this.pb4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb4.Location = new System.Drawing.Point(248, 14);
            this.pb4.Name = "pb4";
            this.pb4.Size = new System.Drawing.Size(60, 80);
            this.pb4.TabIndex = 8;
            this.pb4.TabStop = false;
            // 
            // pb3
            // 
            this.pb3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb3.BackgroundImage")));
            this.pb3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb3.Location = new System.Drawing.Point(172, 14);
            this.pb3.Name = "pb3";
            this.pb3.Size = new System.Drawing.Size(60, 80);
            this.pb3.TabIndex = 7;
            this.pb3.TabStop = false;
            // 
            // pb2
            // 
            this.pb2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb2.BackgroundImage")));
            this.pb2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb2.Location = new System.Drawing.Point(96, 14);
            this.pb2.Name = "pb2";
            this.pb2.Size = new System.Drawing.Size(60, 80);
            this.pb2.TabIndex = 6;
            this.pb2.TabStop = false;
            // 
            // pb1
            // 
            this.pb1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb1.BackgroundImage")));
            this.pb1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb1.Location = new System.Drawing.Point(20, 14);
            this.pb1.Name = "pb1";
            this.pb1.Size = new System.Drawing.Size(60, 80);
            this.pb1.TabIndex = 5;
            this.pb1.TabStop = false;
            // 
            // p3Dispensador
            // 
            this.p3Dispensador.BackColor = System.Drawing.Color.Black;
            this.p3Dispensador.Controls.Add(this.p4Dispensador2);
            this.p3Dispensador.Location = new System.Drawing.Point(3, 526);
            this.p3Dispensador.Name = "p3Dispensador";
            this.p3Dispensador.Size = new System.Drawing.Size(320, 128);
            this.p3Dispensador.TabIndex = 4;
            // 
            // p4Dispensador2
            // 
            this.p4Dispensador2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.p4Dispensador2.Location = new System.Drawing.Point(4, 4);
            this.p4Dispensador2.Name = "p4Dispensador2";
            this.p4Dispensador2.Size = new System.Drawing.Size(312, 120);
            this.p4Dispensador2.TabIndex = 9;
            // 
            // p5Etiquetas4
            // 
            this.p5Etiquetas4.BackColor = System.Drawing.Color.Gray;
            this.p5Etiquetas4.Controls.Add(this.lblSP16);
            this.p5Etiquetas4.Controls.Add(this.lblSP15);
            this.p5Etiquetas4.Controls.Add(this.lblSP14);
            this.p5Etiquetas4.Controls.Add(this.lblSP13);
            this.p5Etiquetas4.Controls.Add(this.label9);
            this.p5Etiquetas4.Controls.Add(this.label10);
            this.p5Etiquetas4.Controls.Add(this.label11);
            this.p5Etiquetas4.Controls.Add(this.label12);
            this.p5Etiquetas4.Location = new System.Drawing.Point(3, 490);
            this.p5Etiquetas4.Name = "p5Etiquetas4";
            this.p5Etiquetas4.Size = new System.Drawing.Size(320, 30);
            this.p5Etiquetas4.TabIndex = 3;
            // 
            // lblSP16
            // 
            this.lblSP16.AutoSize = true;
            this.lblSP16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSP16.Location = new System.Drawing.Point(282, 7);
            this.lblSP16.Name = "lblSP16";
            this.lblSP16.Size = new System.Drawing.Size(0, 15);
            this.lblSP16.TabIndex = 12;
            // 
            // lblSP15
            // 
            this.lblSP15.AutoSize = true;
            this.lblSP15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSP15.Location = new System.Drawing.Point(201, 7);
            this.lblSP15.Name = "lblSP15";
            this.lblSP15.Size = new System.Drawing.Size(0, 15);
            this.lblSP15.TabIndex = 11;
            // 
            // lblSP14
            // 
            this.lblSP14.AutoSize = true;
            this.lblSP14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSP14.Location = new System.Drawing.Point(128, 7);
            this.lblSP14.Name = "lblSP14";
            this.lblSP14.Size = new System.Drawing.Size(0, 15);
            this.lblSP14.TabIndex = 10;
            // 
            // lblSP13
            // 
            this.lblSP13.AutoSize = true;
            this.lblSP13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSP13.Location = new System.Drawing.Point(54, 7);
            this.lblSP13.Name = "lblSP13";
            this.lblSP13.Size = new System.Drawing.Size(0, 15);
            this.lblSP13.TabIndex = 9;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.DarkGray;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(250, 5);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 20);
            this.label9.TabIndex = 3;
            this.label9.Text = "49";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.DarkGray;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(169, 5);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 20);
            this.label10.TabIndex = 2;
            this.label10.Text = "48";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.DarkGray;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(96, 5);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 20);
            this.label11.TabIndex = 1;
            this.label11.Text = "45";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.DarkGray;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(21, 5);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 20);
            this.label12.TabIndex = 0;
            this.label12.Text = "44";
            // 
            // p4Etiquetas3
            // 
            this.p4Etiquetas3.BackColor = System.Drawing.Color.Gray;
            this.p4Etiquetas3.Controls.Add(this.lblSP12);
            this.p4Etiquetas3.Controls.Add(this.lblSP11);
            this.p4Etiquetas3.Controls.Add(this.lblSP10);
            this.p4Etiquetas3.Controls.Add(this.lblSP9);
            this.p4Etiquetas3.Controls.Add(this.label5);
            this.p4Etiquetas3.Controls.Add(this.label6);
            this.p4Etiquetas3.Controls.Add(this.label7);
            this.p4Etiquetas3.Controls.Add(this.label8);
            this.p4Etiquetas3.Location = new System.Drawing.Point(3, 360);
            this.p4Etiquetas3.Name = "p4Etiquetas3";
            this.p4Etiquetas3.Size = new System.Drawing.Size(320, 30);
            this.p4Etiquetas3.TabIndex = 2;
            // 
            // lblSP12
            // 
            this.lblSP12.AutoSize = true;
            this.lblSP12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSP12.Location = new System.Drawing.Point(283, 7);
            this.lblSP12.Name = "lblSP12";
            this.lblSP12.Size = new System.Drawing.Size(0, 15);
            this.lblSP12.TabIndex = 8;
            // 
            // lblSP11
            // 
            this.lblSP11.AutoSize = true;
            this.lblSP11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSP11.Location = new System.Drawing.Point(209, 7);
            this.lblSP11.Name = "lblSP11";
            this.lblSP11.Size = new System.Drawing.Size(0, 15);
            this.lblSP11.TabIndex = 7;
            // 
            // lblSP10
            // 
            this.lblSP10.AutoSize = true;
            this.lblSP10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSP10.Location = new System.Drawing.Point(128, 7);
            this.lblSP10.Name = "lblSP10";
            this.lblSP10.Size = new System.Drawing.Size(0, 15);
            this.lblSP10.TabIndex = 6;
            // 
            // lblSP9
            // 
            this.lblSP9.AutoSize = true;
            this.lblSP9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSP9.Location = new System.Drawing.Point(55, 7);
            this.lblSP9.Name = "lblSP9";
            this.lblSP9.Size = new System.Drawing.Size(0, 15);
            this.lblSP9.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.DarkGray;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(251, 5);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 20);
            this.label5.TabIndex = 3;
            this.label5.Text = "37";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.DarkGray;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(177, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 20);
            this.label6.TabIndex = 2;
            this.label6.Text = "35";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.DarkGray;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(96, 5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 20);
            this.label7.TabIndex = 1;
            this.label7.Text = "33";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.DarkGray;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(23, 5);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 20);
            this.label8.TabIndex = 0;
            this.label8.Text = "30";
            // 
            // p3Etiquetas2
            // 
            this.p3Etiquetas2.BackColor = System.Drawing.Color.Gray;
            this.p3Etiquetas2.Controls.Add(this.lblSP8);
            this.p3Etiquetas2.Controls.Add(this.lblSP7);
            this.p3Etiquetas2.Controls.Add(this.lblSP6);
            this.p3Etiquetas2.Controls.Add(this.lblSP5);
            this.p3Etiquetas2.Controls.Add(this.label1);
            this.p3Etiquetas2.Controls.Add(this.label2);
            this.p3Etiquetas2.Controls.Add(this.label3);
            this.p3Etiquetas2.Controls.Add(this.label4);
            this.p3Etiquetas2.Location = new System.Drawing.Point(3, 230);
            this.p3Etiquetas2.Name = "p3Etiquetas2";
            this.p3Etiquetas2.Size = new System.Drawing.Size(320, 30);
            this.p3Etiquetas2.TabIndex = 1;
            // 
            // lblSP8
            // 
            this.lblSP8.AutoSize = true;
            this.lblSP8.BackColor = System.Drawing.Color.Gray;
            this.lblSP8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSP8.Location = new System.Drawing.Point(277, 7);
            this.lblSP8.Name = "lblSP8";
            this.lblSP8.Size = new System.Drawing.Size(0, 15);
            this.lblSP8.TabIndex = 9;
            // 
            // lblSP7
            // 
            this.lblSP7.AutoSize = true;
            this.lblSP7.BackColor = System.Drawing.Color.Gray;
            this.lblSP7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSP7.Location = new System.Drawing.Point(201, 7);
            this.lblSP7.Name = "lblSP7";
            this.lblSP7.Size = new System.Drawing.Size(0, 15);
            this.lblSP7.TabIndex = 8;
            // 
            // lblSP6
            // 
            this.lblSP6.AutoSize = true;
            this.lblSP6.BackColor = System.Drawing.Color.Gray;
            this.lblSP6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSP6.Location = new System.Drawing.Point(130, 7);
            this.lblSP6.Name = "lblSP6";
            this.lblSP6.Size = new System.Drawing.Size(0, 15);
            this.lblSP6.TabIndex = 7;
            // 
            // lblSP5
            // 
            this.lblSP5.AutoSize = true;
            this.lblSP5.BackColor = System.Drawing.Color.Gray;
            this.lblSP5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSP5.Location = new System.Drawing.Point(54, 7);
            this.lblSP5.Name = "lblSP5";
            this.lblSP5.Size = new System.Drawing.Size(0, 15);
            this.lblSP5.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkGray;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(246, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "28";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkGray;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(170, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "26";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkGray;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(98, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "23";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.DarkGray;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(22, 5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 20);
            this.label4.TabIndex = 0;
            this.label4.Text = "21";
            // 
            // p2Etiquetas1
            // 
            this.p2Etiquetas1.BackColor = System.Drawing.Color.Gray;
            this.p2Etiquetas1.Controls.Add(this.lblSP4);
            this.p2Etiquetas1.Controls.Add(this.lblSP3);
            this.p2Etiquetas1.Controls.Add(this.lblSP2);
            this.p2Etiquetas1.Controls.Add(this.lblSP1);
            this.p2Etiquetas1.Controls.Add(this.lblPrecio4);
            this.p2Etiquetas1.Controls.Add(this.lblPrecio3);
            this.p2Etiquetas1.Controls.Add(this.lblPrecio2);
            this.p2Etiquetas1.Controls.Add(this.lblPrecio1);
            this.p2Etiquetas1.Location = new System.Drawing.Point(3, 100);
            this.p2Etiquetas1.Name = "p2Etiquetas1";
            this.p2Etiquetas1.Size = new System.Drawing.Size(320, 30);
            this.p2Etiquetas1.TabIndex = 0;
            // 
            // lblSP4
            // 
            this.lblSP4.AutoSize = true;
            this.lblSP4.BackColor = System.Drawing.Color.Gray;
            this.lblSP4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSP4.Location = new System.Drawing.Point(285, 7);
            this.lblSP4.Name = "lblSP4";
            this.lblSP4.Size = new System.Drawing.Size(0, 15);
            this.lblSP4.TabIndex = 7;
            // 
            // lblSP3
            // 
            this.lblSP3.AutoSize = true;
            this.lblSP3.BackColor = System.Drawing.Color.Gray;
            this.lblSP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSP3.Location = new System.Drawing.Point(210, 7);
            this.lblSP3.Name = "lblSP3";
            this.lblSP3.Size = new System.Drawing.Size(0, 15);
            this.lblSP3.TabIndex = 6;
            // 
            // lblSP2
            // 
            this.lblSP2.AutoSize = true;
            this.lblSP2.BackColor = System.Drawing.Color.Gray;
            this.lblSP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSP2.Location = new System.Drawing.Point(133, 7);
            this.lblSP2.Name = "lblSP2";
            this.lblSP2.Size = new System.Drawing.Size(0, 15);
            this.lblSP2.TabIndex = 5;
            // 
            // lblSP1
            // 
            this.lblSP1.AutoSize = true;
            this.lblSP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSP1.Location = new System.Drawing.Point(59, 6);
            this.lblSP1.Name = "lblSP1";
            this.lblSP1.Size = new System.Drawing.Size(0, 15);
            this.lblSP1.TabIndex = 4;
            // 
            // lblPrecio4
            // 
            this.lblPrecio4.AutoSize = true;
            this.lblPrecio4.BackColor = System.Drawing.Color.DarkGray;
            this.lblPrecio4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecio4.Location = new System.Drawing.Point(253, 5);
            this.lblPrecio4.Name = "lblPrecio4";
            this.lblPrecio4.Size = new System.Drawing.Size(29, 20);
            this.lblPrecio4.TabIndex = 3;
            this.lblPrecio4.Text = "19";
            // 
            // lblPrecio3
            // 
            this.lblPrecio3.AutoSize = true;
            this.lblPrecio3.BackColor = System.Drawing.Color.DarkGray;
            this.lblPrecio3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecio3.Location = new System.Drawing.Point(178, 5);
            this.lblPrecio3.Name = "lblPrecio3";
            this.lblPrecio3.Size = new System.Drawing.Size(29, 20);
            this.lblPrecio3.TabIndex = 2;
            this.lblPrecio3.Text = "18";
            // 
            // lblPrecio2
            // 
            this.lblPrecio2.AutoSize = true;
            this.lblPrecio2.BackColor = System.Drawing.Color.DarkGray;
            this.lblPrecio2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecio2.Location = new System.Drawing.Point(100, 5);
            this.lblPrecio2.Name = "lblPrecio2";
            this.lblPrecio2.Size = new System.Drawing.Size(29, 20);
            this.lblPrecio2.TabIndex = 1;
            this.lblPrecio2.Text = "15";
            // 
            // lblPrecio1
            // 
            this.lblPrecio1.AutoSize = true;
            this.lblPrecio1.BackColor = System.Drawing.Color.DarkGray;
            this.lblPrecio1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecio1.Location = new System.Drawing.Point(27, 5);
            this.lblPrecio1.Name = "lblPrecio1";
            this.lblPrecio1.Size = new System.Drawing.Size(29, 20);
            this.lblPrecio1.TabIndex = 0;
            this.lblPrecio1.Text = "11";
            // 
            // p1Teclado
            // 
            this.p1Teclado.BackColor = System.Drawing.Color.DarkGray;
            this.p1Teclado.Controls.Add(this.p2Teclado);
            this.p1Teclado.Location = new System.Drawing.Point(366, 153);
            this.p1Teclado.Name = "p1Teclado";
            this.p1Teclado.Size = new System.Drawing.Size(80, 107);
            this.p1Teclado.TabIndex = 6;
            // 
            // p2Teclado
            // 
            this.p2Teclado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.p2Teclado.Controls.Add(this.btCancelar);
            this.p2Teclado.Controls.Add(this.bt0);
            this.p2Teclado.Controls.Add(this.btAceptar);
            this.p2Teclado.Controls.Add(this.bt9);
            this.p2Teclado.Controls.Add(this.bt8);
            this.p2Teclado.Controls.Add(this.bt7);
            this.p2Teclado.Controls.Add(this.bt6);
            this.p2Teclado.Controls.Add(this.bt5);
            this.p2Teclado.Controls.Add(this.bt4);
            this.p2Teclado.Controls.Add(this.bt3);
            this.p2Teclado.Controls.Add(this.bt2);
            this.p2Teclado.Controls.Add(this.bt1);
            this.p2Teclado.Location = new System.Drawing.Point(5, 4);
            this.p2Teclado.Name = "p2Teclado";
            this.p2Teclado.Size = new System.Drawing.Size(70, 98);
            this.p2Teclado.TabIndex = 3;
            // 
            // btCancelar
            // 
            this.btCancelar.Location = new System.Drawing.Point(48, 74);
            this.btCancelar.Name = "btCancelar";
            this.btCancelar.Size = new System.Drawing.Size(20, 20);
            this.btCancelar.TabIndex = 12;
            this.btCancelar.Text = "X";
            this.btCancelar.UseVisualStyleBackColor = true;
            this.btCancelar.Click += new System.EventHandler(this.btCancelar_Click);
            // 
            // bt0
            // 
            this.bt0.Location = new System.Drawing.Point(25, 74);
            this.bt0.Name = "bt0";
            this.bt0.Size = new System.Drawing.Size(20, 20);
            this.bt0.TabIndex = 11;
            this.bt0.Text = "0";
            this.bt0.UseVisualStyleBackColor = true;
            this.bt0.Click += new System.EventHandler(this.bt0_Click);
            // 
            // btAceptar
            // 
            this.btAceptar.Location = new System.Drawing.Point(2, 74);
            this.btAceptar.Name = "btAceptar";
            this.btAceptar.Size = new System.Drawing.Size(20, 20);
            this.btAceptar.TabIndex = 10;
            this.btAceptar.Text = "○";
            this.btAceptar.UseVisualStyleBackColor = true;
            this.btAceptar.Click += new System.EventHandler(this.btAceptar_Click);
            // 
            // bt9
            // 
            this.bt9.Location = new System.Drawing.Point(48, 50);
            this.bt9.Name = "bt9";
            this.bt9.Size = new System.Drawing.Size(20, 20);
            this.bt9.TabIndex = 9;
            this.bt9.Text = "9";
            this.bt9.UseVisualStyleBackColor = true;
            this.bt9.Click += new System.EventHandler(this.bt9_Click);
            // 
            // bt8
            // 
            this.bt8.Location = new System.Drawing.Point(25, 50);
            this.bt8.Name = "bt8";
            this.bt8.Size = new System.Drawing.Size(20, 20);
            this.bt8.TabIndex = 8;
            this.bt8.Text = "8";
            this.bt8.UseVisualStyleBackColor = true;
            this.bt8.Click += new System.EventHandler(this.bt8_Click);
            // 
            // bt7
            // 
            this.bt7.Location = new System.Drawing.Point(2, 50);
            this.bt7.Name = "bt7";
            this.bt7.Size = new System.Drawing.Size(20, 20);
            this.bt7.TabIndex = 7;
            this.bt7.Text = "7";
            this.bt7.UseVisualStyleBackColor = true;
            this.bt7.Click += new System.EventHandler(this.bt7_Click);
            // 
            // bt6
            // 
            this.bt6.Location = new System.Drawing.Point(48, 26);
            this.bt6.Name = "bt6";
            this.bt6.Size = new System.Drawing.Size(20, 20);
            this.bt6.TabIndex = 6;
            this.bt6.Text = "6";
            this.bt6.UseVisualStyleBackColor = true;
            this.bt6.Click += new System.EventHandler(this.bt6_Click);
            // 
            // bt5
            // 
            this.bt5.Location = new System.Drawing.Point(25, 26);
            this.bt5.Name = "bt5";
            this.bt5.Size = new System.Drawing.Size(20, 20);
            this.bt5.TabIndex = 5;
            this.bt5.Text = "5";
            this.bt5.UseVisualStyleBackColor = true;
            this.bt5.Click += new System.EventHandler(this.bt5_Click);
            // 
            // bt4
            // 
            this.bt4.Location = new System.Drawing.Point(2, 26);
            this.bt4.Name = "bt4";
            this.bt4.Size = new System.Drawing.Size(20, 20);
            this.bt4.TabIndex = 4;
            this.bt4.Text = "4";
            this.bt4.UseVisualStyleBackColor = true;
            this.bt4.Click += new System.EventHandler(this.bt4_Click);
            // 
            // bt3
            // 
            this.bt3.Location = new System.Drawing.Point(48, 2);
            this.bt3.Name = "bt3";
            this.bt3.Size = new System.Drawing.Size(20, 20);
            this.bt3.TabIndex = 3;
            this.bt3.Text = "3";
            this.bt3.UseVisualStyleBackColor = true;
            this.bt3.Click += new System.EventHandler(this.bt3_Click);
            // 
            // bt2
            // 
            this.bt2.Location = new System.Drawing.Point(25, 2);
            this.bt2.Name = "bt2";
            this.bt2.Size = new System.Drawing.Size(20, 20);
            this.bt2.TabIndex = 2;
            this.bt2.Text = "2";
            this.bt2.UseVisualStyleBackColor = true;
            this.bt2.Click += new System.EventHandler(this.bt2_Click);
            // 
            // bt1
            // 
            this.bt1.Location = new System.Drawing.Point(2, 2);
            this.bt1.Name = "bt1";
            this.bt1.Size = new System.Drawing.Size(20, 20);
            this.bt1.TabIndex = 0;
            this.bt1.Text = "1";
            this.bt1.UseVisualStyleBackColor = true;
            this.bt1.Click += new System.EventHandler(this.bt1_Click);
            // 
            // txtPantalla
            // 
            this.txtPantalla.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtPantalla.Enabled = false;
            this.txtPantalla.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPantalla.Location = new System.Drawing.Point(371, 101);
            this.txtPantalla.MaxLength = 2;
            this.txtPantalla.Name = "txtPantalla";
            this.txtPantalla.ReadOnly = true;
            this.txtPantalla.Size = new System.Drawing.Size(70, 29);
            this.txtPantalla.TabIndex = 5;
            // 
            // p1Cambio
            // 
            this.p1Cambio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.p1Cambio.Controls.Add(this.p2Cambio);
            this.p1Cambio.Location = new System.Drawing.Point(380, 403);
            this.p1Cambio.Name = "p1Cambio";
            this.p1Cambio.Size = new System.Drawing.Size(58, 31);
            this.p1Cambio.TabIndex = 11;
            // 
            // p2Cambio
            // 
            this.p2Cambio.BackColor = System.Drawing.Color.Silver;
            this.p2Cambio.Location = new System.Drawing.Point(3, 4);
            this.p2Cambio.Name = "p2Cambio";
            this.p2Cambio.Size = new System.Drawing.Size(52, 24);
            this.p2Cambio.TabIndex = 12;
            // 
            // lblPantalla
            // 
            this.lblPantalla.AutoSize = true;
            this.lblPantalla.BackColor = System.Drawing.Color.Black;
            this.lblPantalla.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPantalla.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblPantalla.Location = new System.Drawing.Point(364, 45);
            this.lblPantalla.MaximumSize = new System.Drawing.Size(99, 0);
            this.lblPantalla.Name = "lblPantalla";
            this.lblPantalla.Size = new System.Drawing.Size(0, 16);
            this.lblPantalla.TabIndex = 12;
            // 
            // lblCambio
            // 
            this.lblCambio.AutoSize = true;
            this.lblCambio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCambio.ForeColor = System.Drawing.Color.White;
            this.lblCambio.Location = new System.Drawing.Point(367, 452);
            this.lblCambio.Name = "lblCambio";
            this.lblCambio.Size = new System.Drawing.Size(0, 18);
            this.lblCambio.TabIndex = 13;
            // 
            // pbBilletes
            // 
            this.pbBilletes.BackgroundImage = global::MaquinaExpEstado03.Properties.Resources.rectangulo_redondeado;
            this.pbBilletes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbBilletes.Location = new System.Drawing.Point(376, 332);
            this.pbBilletes.Name = "pbBilletes";
            this.pbBilletes.Size = new System.Drawing.Size(70, 11);
            this.pbBilletes.TabIndex = 10;
            this.pbBilletes.TabStop = false;
            this.pbBilletes.Click += new System.EventHandler(this.pbBilletes_Click);
            this.pbBilletes.DoubleClick += new System.EventHandler(this.pbBilletes_DoubleClick);
            // 
            // pbMonedas
            // 
            this.pbMonedas.BackgroundImage = global::MaquinaExpEstado03.Properties.Resources.inserte_moneda;
            this.pbMonedas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbMonedas.Location = new System.Drawing.Point(406, 282);
            this.pbMonedas.Name = "pbMonedas";
            this.pbMonedas.Size = new System.Drawing.Size(35, 35);
            this.pbMonedas.TabIndex = 9;
            this.pbMonedas.TabStop = false;
            this.pbMonedas.Click += new System.EventHandler(this.pbMonedas_Click);
            this.pbMonedas.DoubleClick += new System.EventHandler(this.pbMonedas_DoubleClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(461, 690);
            this.Controls.Add(this.lblCambio);
            this.Controls.Add(this.lblPantalla);
            this.Controls.Add(this.p1Cambio);
            this.Controls.Add(this.pbBilletes);
            this.Controls.Add(this.pbMonedas);
            this.Controls.Add(this.p1Fondo);
            this.Controls.Add(this.p1Teclado);
            this.Controls.Add(this.txtPantalla);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.DoubleClick += new System.EventHandler(this.Form1_DoubleClick);
            this.p1Fondo.ResumeLayout(false);
            this.p2Fondo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).EndInit();
            this.p3Dispensador.ResumeLayout(false);
            this.p5Etiquetas4.ResumeLayout(false);
            this.p5Etiquetas4.PerformLayout();
            this.p4Etiquetas3.ResumeLayout(false);
            this.p4Etiquetas3.PerformLayout();
            this.p3Etiquetas2.ResumeLayout(false);
            this.p3Etiquetas2.PerformLayout();
            this.p2Etiquetas1.ResumeLayout(false);
            this.p2Etiquetas1.PerformLayout();
            this.p1Teclado.ResumeLayout(false);
            this.p2Teclado.ResumeLayout(false);
            this.p1Cambio.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbBilletes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMonedas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel p1Fondo;
        private System.Windows.Forms.Panel p2Fondo;
        private System.Windows.Forms.PictureBox pb8;
        private System.Windows.Forms.PictureBox pb7;
        private System.Windows.Forms.PictureBox pb6;
        private System.Windows.Forms.PictureBox pb5;
        private System.Windows.Forms.PictureBox pb16;
        private System.Windows.Forms.PictureBox pb15;
        private System.Windows.Forms.PictureBox pb14;
        private System.Windows.Forms.PictureBox pb13;
        private System.Windows.Forms.PictureBox pb4;
        private System.Windows.Forms.PictureBox pb3;
        private System.Windows.Forms.PictureBox pb2;
        private System.Windows.Forms.PictureBox pb1;
        private System.Windows.Forms.Panel p3Dispensador;
        private System.Windows.Forms.Panel p5Etiquetas4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel p4Etiquetas3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel p3Etiquetas2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel p2Etiquetas1;
        private System.Windows.Forms.Label lblPrecio4;
        private System.Windows.Forms.Label lblPrecio3;
        private System.Windows.Forms.Label lblPrecio2;
        private System.Windows.Forms.Label lblPrecio1;
        private System.Windows.Forms.Panel p1Teclado;
        private System.Windows.Forms.Panel p2Teclado;
        private System.Windows.Forms.Button btCancelar;
        private System.Windows.Forms.Button bt0;
        private System.Windows.Forms.Button btAceptar;
        private System.Windows.Forms.Button bt9;
        private System.Windows.Forms.Button bt8;
        private System.Windows.Forms.Button bt7;
        private System.Windows.Forms.Button bt6;
        private System.Windows.Forms.Button bt5;
        private System.Windows.Forms.Button bt4;
        private System.Windows.Forms.Button bt3;
        private System.Windows.Forms.Button bt2;
        private System.Windows.Forms.Button bt1;
        private System.Windows.Forms.TextBox txtPantalla;
        private System.Windows.Forms.PictureBox pb12;
        private System.Windows.Forms.PictureBox pb11;
        private System.Windows.Forms.PictureBox pb10;
        private System.Windows.Forms.PictureBox pb9;
        private System.Windows.Forms.PictureBox pbMonedas;
        private System.Windows.Forms.PictureBox pbBilletes;
        private System.Windows.Forms.Panel p1Cambio;
        private System.Windows.Forms.Panel p2Cambio;
        private System.Windows.Forms.Label lblPantalla;
        private System.Windows.Forms.Timer tmPrecio;
        private System.Windows.Forms.Timer tmLimpiar;
        private System.Windows.Forms.Label lblCambio;
        private System.Windows.Forms.Timer tmDispensar;
        private System.Windows.Forms.Label lblSP1;
        private System.Windows.Forms.Label lblSP4;
        private System.Windows.Forms.Label lblSP3;
        private System.Windows.Forms.Label lblSP2;
        private System.Windows.Forms.Label lblSP9;
        private System.Windows.Forms.Label lblSP8;
        private System.Windows.Forms.Label lblSP7;
        private System.Windows.Forms.Label lblSP6;
        private System.Windows.Forms.Label lblSP5;
        private System.Windows.Forms.Label lblSP16;
        private System.Windows.Forms.Label lblSP15;
        private System.Windows.Forms.Label lblSP14;
        private System.Windows.Forms.Label lblSP13;
        private System.Windows.Forms.Label lblSP12;
        private System.Windows.Forms.Label lblSP11;
        private System.Windows.Forms.Label lblSP10;
        private System.Windows.Forms.Panel p4Dispensador2;
    }
}

