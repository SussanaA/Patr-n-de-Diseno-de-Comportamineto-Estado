﻿namespace MaquinaExpEstado03
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbMoneda10 = new System.Windows.Forms.PictureBox();
            this.pbMoneda5 = new System.Windows.Forms.PictureBox();
            this.pbMoneda1 = new System.Windows.Forms.PictureBox();
            this.pbMoneda2 = new System.Windows.Forms.PictureBox();
            this.lblMoneda1 = new System.Windows.Forms.Label();
            this.lblMoneda2 = new System.Windows.Forms.Label();
            this.lblMoneda5 = new System.Windows.Forms.Label();
            this.lblMoneda10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbMoneda10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMoneda5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMoneda1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMoneda2)).BeginInit();
            this.SuspendLayout();
            // 
            // pbMoneda10
            // 
            this.pbMoneda10.BackgroundImage = global::MaquinaExpEstado03.Properties.Resources.moneda__10;
            this.pbMoneda10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbMoneda10.Location = new System.Drawing.Point(236, 13);
            this.pbMoneda10.Name = "pbMoneda10";
            this.pbMoneda10.Size = new System.Drawing.Size(85, 85);
            this.pbMoneda10.TabIndex = 1;
            this.pbMoneda10.TabStop = false;
            this.pbMoneda10.Click += new System.EventHandler(this.pbMoneda10_Click);
            // 
            // pbMoneda5
            // 
            this.pbMoneda5.BackgroundImage = global::MaquinaExpEstado03.Properties.Resources.moneda__5;
            this.pbMoneda5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbMoneda5.Location = new System.Drawing.Point(148, 23);
            this.pbMoneda5.Name = "pbMoneda5";
            this.pbMoneda5.Size = new System.Drawing.Size(75, 75);
            this.pbMoneda5.TabIndex = 0;
            this.pbMoneda5.TabStop = false;
            this.pbMoneda5.Click += new System.EventHandler(this.pbMoneda5_Click);
            // 
            // pbMoneda1
            // 
            this.pbMoneda1.BackgroundImage = global::MaquinaExpEstado03.Properties.Resources.moneda__5;
            this.pbMoneda1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbMoneda1.Location = new System.Drawing.Point(12, 48);
            this.pbMoneda1.Name = "pbMoneda1";
            this.pbMoneda1.Size = new System.Drawing.Size(50, 50);
            this.pbMoneda1.TabIndex = 2;
            this.pbMoneda1.TabStop = false;
            this.pbMoneda1.Click += new System.EventHandler(this.pbMoneda1_Click);
            // 
            // pbMoneda2
            // 
            this.pbMoneda2.BackgroundImage = global::MaquinaExpEstado03.Properties.Resources.moneda__5;
            this.pbMoneda2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbMoneda2.Location = new System.Drawing.Point(75, 38);
            this.pbMoneda2.Name = "pbMoneda2";
            this.pbMoneda2.Size = new System.Drawing.Size(60, 60);
            this.pbMoneda2.TabIndex = 3;
            this.pbMoneda2.TabStop = false;
            this.pbMoneda2.Click += new System.EventHandler(this.pbMoneda2_Click);
            // 
            // lblMoneda1
            // 
            this.lblMoneda1.AutoSize = true;
            this.lblMoneda1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lblMoneda1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMoneda1.ForeColor = System.Drawing.Color.White;
            this.lblMoneda1.Location = new System.Drawing.Point(22, 107);
            this.lblMoneda1.Name = "lblMoneda1";
            this.lblMoneda1.Size = new System.Drawing.Size(29, 20);
            this.lblMoneda1.TabIndex = 4;
            this.lblMoneda1.Text = "$1";
            // 
            // lblMoneda2
            // 
            this.lblMoneda2.AutoSize = true;
            this.lblMoneda2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lblMoneda2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMoneda2.ForeColor = System.Drawing.Color.White;
            this.lblMoneda2.Location = new System.Drawing.Point(91, 108);
            this.lblMoneda2.Name = "lblMoneda2";
            this.lblMoneda2.Size = new System.Drawing.Size(29, 20);
            this.lblMoneda2.TabIndex = 5;
            this.lblMoneda2.Text = "$2";
            // 
            // lblMoneda5
            // 
            this.lblMoneda5.AutoSize = true;
            this.lblMoneda5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lblMoneda5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMoneda5.ForeColor = System.Drawing.Color.White;
            this.lblMoneda5.Location = new System.Drawing.Point(171, 107);
            this.lblMoneda5.Name = "lblMoneda5";
            this.lblMoneda5.Size = new System.Drawing.Size(29, 20);
            this.lblMoneda5.TabIndex = 6;
            this.lblMoneda5.Text = "$5";
            // 
            // lblMoneda10
            // 
            this.lblMoneda10.AutoSize = true;
            this.lblMoneda10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lblMoneda10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMoneda10.ForeColor = System.Drawing.Color.White;
            this.lblMoneda10.Location = new System.Drawing.Point(259, 107);
            this.lblMoneda10.Name = "lblMoneda10";
            this.lblMoneda10.Size = new System.Drawing.Size(39, 20);
            this.lblMoneda10.TabIndex = 7;
            this.lblMoneda10.Text = "$10";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(335, 135);
            this.Controls.Add(this.lblMoneda10);
            this.Controls.Add(this.lblMoneda5);
            this.Controls.Add(this.lblMoneda2);
            this.Controls.Add(this.lblMoneda1);
            this.Controls.Add(this.pbMoneda2);
            this.Controls.Add(this.pbMoneda1);
            this.Controls.Add(this.pbMoneda10);
            this.Controls.Add(this.pbMoneda5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(920, 240);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbMoneda10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMoneda5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMoneda1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMoneda2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbMoneda5;
        private System.Windows.Forms.PictureBox pbMoneda10;
        private System.Windows.Forms.PictureBox pbMoneda1;
        private System.Windows.Forms.PictureBox pbMoneda2;
        private System.Windows.Forms.Label lblMoneda1;
        private System.Windows.Forms.Label lblMoneda2;
        private System.Windows.Forms.Label lblMoneda5;
        private System.Windows.Forms.Label lblMoneda10;
    }
}