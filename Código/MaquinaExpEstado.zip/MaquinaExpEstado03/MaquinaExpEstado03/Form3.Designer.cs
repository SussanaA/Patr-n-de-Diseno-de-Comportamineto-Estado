﻿namespace MaquinaExpEstado03
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbBillete100 = new System.Windows.Forms.PictureBox();
            this.pbBillete50 = new System.Windows.Forms.PictureBox();
            this.pbBillete20 = new System.Windows.Forms.PictureBox();
            this.lblBillete20 = new System.Windows.Forms.Label();
            this.lblBillete50 = new System.Windows.Forms.Label();
            this.lblBillete100 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbBillete100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBillete50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBillete20)).BeginInit();
            this.SuspendLayout();
            // 
            // pbBillete100
            // 
            this.pbBillete100.BackgroundImage = global::MaquinaExpEstado03.Properties.Resources.dinero__100_;
            this.pbBillete100.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbBillete100.Location = new System.Drawing.Point(164, 12);
            this.pbBillete100.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.pbBillete100.Name = "pbBillete100";
            this.pbBillete100.Size = new System.Drawing.Size(85, 100);
            this.pbBillete100.TabIndex = 2;
            this.pbBillete100.TabStop = false;
            this.pbBillete100.Click += new System.EventHandler(this.pbBillete100_Click);
            // 
            // pbBillete50
            // 
            this.pbBillete50.BackgroundImage = global::MaquinaExpEstado03.Properties.Resources.dinero__50_;
            this.pbBillete50.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbBillete50.Location = new System.Drawing.Point(83, 12);
            this.pbBillete50.Name = "pbBillete50";
            this.pbBillete50.Size = new System.Drawing.Size(85, 100);
            this.pbBillete50.TabIndex = 1;
            this.pbBillete50.TabStop = false;
            this.pbBillete50.Click += new System.EventHandler(this.pbBillete50_Click);
            // 
            // pbBillete20
            // 
            this.pbBillete20.BackgroundImage = global::MaquinaExpEstado03.Properties.Resources.dinero__20_;
            this.pbBillete20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbBillete20.Location = new System.Drawing.Point(2, 12);
            this.pbBillete20.Name = "pbBillete20";
            this.pbBillete20.Size = new System.Drawing.Size(85, 100);
            this.pbBillete20.TabIndex = 0;
            this.pbBillete20.TabStop = false;
            this.pbBillete20.Click += new System.EventHandler(this.pbBillete20_Click);
            // 
            // lblBillete20
            // 
            this.lblBillete20.AutoSize = true;
            this.lblBillete20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lblBillete20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBillete20.ForeColor = System.Drawing.Color.White;
            this.lblBillete20.Location = new System.Drawing.Point(27, 123);
            this.lblBillete20.Name = "lblBillete20";
            this.lblBillete20.Size = new System.Drawing.Size(39, 20);
            this.lblBillete20.TabIndex = 8;
            this.lblBillete20.Text = "$20";
            // 
            // lblBillete50
            // 
            this.lblBillete50.AutoSize = true;
            this.lblBillete50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lblBillete50.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBillete50.ForeColor = System.Drawing.Color.White;
            this.lblBillete50.Location = new System.Drawing.Point(106, 123);
            this.lblBillete50.Name = "lblBillete50";
            this.lblBillete50.Size = new System.Drawing.Size(39, 20);
            this.lblBillete50.TabIndex = 9;
            this.lblBillete50.Text = "$50";
            // 
            // lblBillete100
            // 
            this.lblBillete100.AutoSize = true;
            this.lblBillete100.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lblBillete100.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBillete100.ForeColor = System.Drawing.Color.White;
            this.lblBillete100.Location = new System.Drawing.Point(184, 123);
            this.lblBillete100.Name = "lblBillete100";
            this.lblBillete100.Size = new System.Drawing.Size(49, 20);
            this.lblBillete100.TabIndex = 10;
            this.lblBillete100.Text = "$100";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(250, 160);
            this.Controls.Add(this.lblBillete100);
            this.Controls.Add(this.lblBillete50);
            this.Controls.Add(this.lblBillete20);
            this.Controls.Add(this.pbBillete100);
            this.Controls.Add(this.pbBillete50);
            this.Controls.Add(this.pbBillete20);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(920, 360);
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbBillete100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBillete50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBillete20)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbBillete20;
        private System.Windows.Forms.PictureBox pbBillete50;
        private System.Windows.Forms.PictureBox pbBillete100;
        private System.Windows.Forms.Label lblBillete20;
        private System.Windows.Forms.Label lblBillete50;
        private System.Windows.Forms.Label lblBillete100;
    }
}